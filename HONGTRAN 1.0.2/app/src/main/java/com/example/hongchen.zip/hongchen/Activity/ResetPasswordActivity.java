package com.example.hongchen.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.hongchen.R;

public class ResetPasswordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resetpassword);
    }
}
